# FIXED

control/line_control.o: ../control/line_control.c \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/control/line_control.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/control/pid.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/line_sensor.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/control/line_control.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/control/pid.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/line_sensor.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h:

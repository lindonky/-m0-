# FIXED

drivers/tb6612.o: ../drivers/tb6612.c \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/tb6612.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_tb6612.h
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/tb6612.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_tb6612.h:

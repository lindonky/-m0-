# FIXED

drivers/imu.o: ../drivers/imu.c \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/imu.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_imu_uart.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/imu.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_imu_uart.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h:

# FIXED

drivers/encoder.o: ../drivers/encoder.c \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/encoder.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_encoder.h \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/encoder.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/bsp/bsp_encoder.h:
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/config/car_config.h:

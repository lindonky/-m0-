# FIXED

drivers/oled_data.o: ../drivers/oled_data.c \
 C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/oled_data.h
C:/ti/workspace_ccstheia/empty_LP_MSPM0G3507_nortos_ticlang/drivers/oled_data.h:
